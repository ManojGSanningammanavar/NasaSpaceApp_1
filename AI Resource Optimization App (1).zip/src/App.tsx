import { useState } from 'react';
import { WeatherQuery } from './components/WeatherQuery';
import { WeatherPrediction } from './components/WeatherPrediction';
import { EventSuggestions } from './components/EventSuggestions';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { CloudRain, Satellite, Brain, MapPin } from 'lucide-react';

interface QueryData {
  location: string;
  date: string;
  time: string;
  eventType: string;
  riskType: string;
}

export default function App() {
  const [queryData, setQueryData] = useState<QueryData | null>(null);
  const [showResults, setShowResults] = useState(false);

  const handleQuery = (data: QueryData) => {
    setQueryData(data);
    setShowResults(true);
  };

  const handleNewQuery = () => {
    setShowResults(false);
    setQueryData(null);
  };

  // Calculate risk level for suggestions
  const getRiskLevel = (): 'low-risk' | 'moderate-risk' | 'high-risk' => {
    const random = Math.random() * 100;
    if (random > 70) return 'high-risk';
    if (random > 40) return 'moderate-risk';
    return 'low-risk';
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 p-2 bg-primary/10 rounded-lg">
                <CloudRain className="w-6 h-6 text-primary" />
                <Satellite className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">Will It Rain On My Parade?</h1>
                <p className="text-muted-foreground">NASA-powered weather predictions for perfect event planning</p>
              </div>
            </div>
            {showResults && (
              <button
                onClick={handleNewQuery}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
              >
                New Query
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {!showResults ? (
          <div className="space-y-8">
            {/* Hero Section */}
            <div className="text-center space-y-4 max-w-3xl mx-auto">
              <div className="flex justify-center gap-2 mb-4">
                <Badge variant="outline" className="flex items-center gap-1">
                  <Brain className="w-3 h-3" />
                  AI-Powered
                </Badge>
                <Badge variant="outline" className="flex items-center gap-1">
                  <Satellite className="w-3 h-3" />
                  NASA Data
                </Badge>
                <Badge variant="outline" className="flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  Location-Specific
                </Badge>
              </div>
              <h2 className="text-3xl font-bold">Plan Events with Confidence</h2>
              <p className="text-lg text-muted-foreground">
                Get personalized weather risk assessments using real NASA Earth observation data. 
                Our AI analyzes satellite imagery, precipitation estimates, and atmospheric conditions 
                to help you make informed decisions about your outdoor events.
              </p>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardContent className="p-6 text-center space-y-3">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto">
                    <Satellite className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3>Real NASA Data</h3>
                  <p className="text-sm text-muted-foreground">
                    Live satellite precipitation, cloud cover, humidity, and temperature data from NASA's Earth observation systems.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center space-y-3">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto">
                    <Brain className="w-6 h-6 text-green-600" />
                  </div>
                  <h3>AI Analysis</h3>
                  <p className="text-sm text-muted-foreground">
                    Advanced machine learning algorithms analyze weather patterns to predict risks for your specific event type and location.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center space-y-3">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto">
                    <MapPin className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3>Smart Suggestions</h3>
                  <p className="text-sm text-muted-foreground">
                    Get personalized recommendations, backup plans, and alternative dates based on your event type and weather concerns.
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Query Form */}
            <WeatherQuery onQuery={handleQuery} />
          </div>
        ) : (
          queryData && (
            <div className="space-y-8">
              {/* Results Header */}
              <div className="text-center space-y-2">
                <h2 className="text-2xl font-bold">Weather Analysis Complete</h2>
                <p className="text-muted-foreground">
                  AI-powered predictions based on NASA Earth observation data
                </p>
              </div>

              {/* Results Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Weather Prediction - Takes 2 columns */}
                <div className="lg:col-span-2">
                  <WeatherPrediction queryData={queryData} />
                </div>

                {/* Event Suggestions - Takes 1 column */}
                <div className="lg:col-span-1">
                  <EventSuggestions 
                    queryData={queryData} 
                    riskLevel={getRiskLevel()}
                  />
                </div>
              </div>
            </div>
          )
        )}
      </main>

      {/* Footer */}
      <footer className="border-t bg-muted/30 mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center space-y-4">
            <div className="flex justify-center items-center gap-2">
              <Satellite className="w-5 h-5 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                Powered by NASA Earth Science Data and AI Technology
              </span>
            </div>
            <p className="text-xs text-muted-foreground max-w-2xl mx-auto">
              This application uses NASA's open Earth observation datasets including satellite-based precipitation estimates, 
              cloud cover analysis, humidity measurements, and temperature trends to provide accurate weather predictions 
              for informed event planning decisions.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}