import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  Umbrella, 
  Tent, 
  Calendar, 
  MapPin, 
  Shield, 
  Clock,
  AlertCircle,
  Lightbulb,
  CheckCircle2
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface EventSuggestionsProps {
  queryData: {
    location: string;
    date: string;
    time: string;
    eventType: string;
    riskType: string;
  };
  riskLevel: 'low-risk' | 'moderate-risk' | 'high-risk';
}

export function EventSuggestions({ queryData, riskLevel }: EventSuggestionsProps) {
  const suggestions = {
    'low-risk': {
      title: 'Perfect Conditions Ahead!',
      icon: <CheckCircle2 className="w-5 h-5 text-green-600" />,
      tips: [
        'Enjoy your outdoor event with confidence',
        'Consider extending the duration since conditions are favorable',
        'Great opportunity for photography and outdoor activities',
        'No special weather preparations needed'
      ],
      preparations: [],
      alternatives: []
    },
    'moderate-risk': {
      title: 'Proceed with Weather Awareness',
      icon: <AlertCircle className="w-5 h-5 text-yellow-600" />,
      tips: [
        'Monitor weather updates 24 hours before the event',
        'Have indoor backup options readily available',
        'Prepare weather-appropriate gear and clothing',
        'Consider shortening outdoor exposure time'
      ],
      preparations: [
        { item: 'Portable Weather Radio', icon: <Shield className="w-4 h-4" /> },
        { item: 'Emergency Shelter/Tent', icon: <Tent className="w-4 h-4" /> },
        { item: 'Weather-resistant Equipment', icon: <Umbrella className="w-4 h-4" /> }
      ],
      alternatives: []
    },
    'high-risk': {
      title: 'Consider Safer Alternatives',
      icon: <AlertCircle className="w-5 h-5 text-red-600" />,
      tips: [
        'Strongly recommend rescheduling to a safer date',
        'If proceeding, move to an indoor or covered venue',
        'Have emergency evacuation plans ready',
        'Inform all participants about weather risks'
      ],
      preparations: [
        { item: 'Indoor Venue Backup', icon: <Shield className="w-4 h-4" /> },
        { item: 'Emergency Weather Kit', icon: <Umbrella className="w-4 h-4" /> },
        { item: 'Communication Plan', icon: <MapPin className="w-4 h-4" /> }
      ],
      alternatives: [
        { date: getAlternativeDate(1), reason: 'Lower precipitation probability' },
        { date: getAlternativeDate(3), reason: 'More stable atmospheric conditions' },
        { date: getAlternativeDate(7), reason: 'Improved weather pattern expected' }
      ]
    }
  };

  function getAlternativeDate(daysOffset: number): string {
    const date = new Date(queryData.date);
    date.setDate(date.getDate() + daysOffset);
    return date.toLocaleDateString();
  }

  const currentSuggestions = suggestions[riskLevel];

  const getEventSpecificAdvice = () => {
    const advice = {
      'outdoor-wedding': {
        items: ['Consider a tent rental', 'Have a photo backup plan', 'Prepare guest comfort items'],
        icon: '💒'
      },
      'hiking': {
        items: ['Check trail conditions', 'Bring extra layers', 'Share your route plan'],
        icon: '🥾'
      },
      'fishing': {
        items: ['Monitor water conditions', 'Bring weather protection', 'Check local advisories'],
        icon: '🎣'
      },
      'camping': {
        items: ['Waterproof your gear', 'Plan covered cooking area', 'Have exit strategy'],
        icon: '⛺'
      },
      'sports': {
        items: ['Consider field conditions', 'Prepare player safety gear', 'Have medical support'],
        icon: '⚽'
      },
      'festival': {
        items: ['Set up weather stations', 'Prepare crowd protection', 'Plan stage coverage'],
        icon: '🎪'
      },
      'picnic': {
        items: ['Bring portable shelter', 'Pack weather-resistant food', 'Have indoor alternatives'],
        icon: '🧺'
      },
      'photography': {
        items: ['Protect camera equipment', 'Plan alternative shooting locations', 'Use weather as creative element'],
        icon: '📸'
      },
      'other': {
        items: ['Assess activity-specific risks', 'Prepare general weather protection', 'Have contingency plans'],
        icon: '🌟'
      }
    };

    return advice[queryData.eventType as keyof typeof advice] || advice.other;
  };

  const eventAdvice = getEventSpecificAdvice();

  return (
    <div className="space-y-6">
      {/* Main Suggestions Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="w-5 h-5" />
            AI-Powered Event Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Risk Level Header */}
          <div className="flex items-center gap-2">
            {currentSuggestions.icon}
            <h3>{currentSuggestions.title}</h3>
          </div>

          {/* General Tips */}
          <div className="space-y-3">
            <h4>General Recommendations</h4>
            <ul className="space-y-2">
              {currentSuggestions.tips.map((tip, index) => (
                <li key={index} className="flex items-start gap-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                  <span>{tip}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Event-Specific Advice */}
          <div className="bg-muted/50 rounded-lg p-4 space-y-3">
            <h4 className="flex items-center gap-2">
              <span className="text-lg">{eventAdvice.icon}</span>
              Specific Advice for {queryData.eventType.replace('-', ' ')}
            </h4>
            <ul className="space-y-2">
              {eventAdvice.items.map((item, index) => (
                <li key={index} className="flex items-start gap-2 text-sm">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Preparations Needed */}
          {currentSuggestions.preparations.length > 0 && (
            <div className="space-y-3">
              <h4>Recommended Preparations</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {currentSuggestions.preparations.map((prep, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
                    {prep.icon}
                    <span className="text-sm">{prep.item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Alternative Dates */}
          {currentSuggestions.alternatives.length > 0 && (
            <div className="space-y-3">
              <h4 className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Suggested Alternative Dates
              </h4>
              <div className="space-y-2">
                {currentSuggestions.alternatives.map((alt, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div>
                      <div className="font-medium">{alt.date}</div>
                      <div className="text-sm text-muted-foreground">{alt.reason}</div>
                    </div>
                    <Button variant="outline" size="sm">
                      <Clock className="w-3 h-3 mr-1" />
                      Check Date
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Protection Strategies */}
      <Card>
        <CardHeader>
          <CardTitle>Weather Protection Strategies</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative rounded-lg overflow-hidden bg-muted">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1560962710-5eb7be39d9d7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdXRkb29yJTIwZXZlbnQlMjBmZXN0aXZhbCUyMHJhaW4lMjBwcm90ZWN0aW9ufGVufDF8fHx8MTc1OTY4MjU0OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Outdoor event weather protection strategies"
              className="w-full h-48 object-cover"
            />
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
              <div className="text-center text-white">
                <Shield className="w-8 h-8 mx-auto mb-2" />
                <div className="font-medium">Smart Protection Planning</div>
                <div className="text-sm opacity-90">Be prepared for any weather scenario</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}