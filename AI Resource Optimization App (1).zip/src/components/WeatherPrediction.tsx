import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { AlertTriangle, CheckCircle, XCircle, TrendingUp, Satellite, Brain } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface WeatherData {
  location: string;
  date: string;
  time: string;
  eventType: string;
  riskType: string;
}

interface WeatherPredictionProps {
  queryData: WeatherData;
}

export function WeatherPrediction({ queryData }: WeatherPredictionProps) {
  // Mock NASA data processing
  const generatePrediction = () => {
    const riskScores = {
      'very-wet': Math.random() * 100,
      'very-hot': Math.random() * 100,
      'very-cold': Math.random() * 100,
      'very-windy': Math.random() * 100,
      'very-uncomfortable': Math.random() * 100,
    };

    const primaryRisk = riskScores[queryData.riskType as keyof typeof riskScores];
    const overallRisk = Object.values(riskScores).reduce((sum, val) => sum + val, 0) / 5;

    return {
      primaryRisk,
      overallRisk,
      riskScores,
      confidence: 85 + Math.random() * 10,
      satelliteData: {
        precipitationEstimate: Math.random() * 20,
        cloudCover: Math.random() * 100,
        humidity: 40 + Math.random() * 50,
        temperature: 15 + Math.random() * 25,
        windSpeed: Math.random() * 30,
        pressure: 995 + Math.random() * 40,
      },
      recommendation: primaryRisk > 70 ? 'high-risk' : primaryRisk > 40 ? 'moderate-risk' : 'low-risk'
    };
  };

  const prediction = generatePrediction();

  const getRiskColor = (risk: number) => {
    if (risk > 70) return 'text-red-600 bg-red-50';
    if (risk > 40) return 'text-yellow-600 bg-yellow-50';
    return 'text-green-600 bg-green-50';
  };

  const getRiskIcon = (risk: number) => {
    if (risk > 70) return <XCircle className="w-5 h-5" />;
    if (risk > 40) return <AlertTriangle className="w-5 h-5" />;
    return <CheckCircle className="w-5 h-5" />;
  };

  const getRecommendationText = () => {
    switch (prediction.recommendation) {
      case 'high-risk':
        return 'Consider rescheduling or moving indoors. High probability of adverse conditions.';
      case 'moderate-risk':
        return 'Proceed with caution. Have backup plans and weather protection ready.';
      default:
        return 'Great conditions expected! Perfect time for your outdoor event.';
    }
  };

  return (
    <div className="space-y-6">
      {/* Main Prediction Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5" />
            AI Weather Analysis for {queryData.location}
          </CardTitle>
          <p className="text-muted-foreground">
            {new Date(queryData.date).toLocaleDateString()} at {queryData.time} • {queryData.eventType.replace('-', ' ')}
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Overall Risk Assessment */}
          <div className="text-center space-y-4">
            <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg ${getRiskColor(prediction.primaryRisk)}`}>
              {getRiskIcon(prediction.primaryRisk)}
              <span className="font-medium">
                {prediction.primaryRisk > 70 ? 'High Risk' : prediction.primaryRisk > 40 ? 'Moderate Risk' : 'Low Risk'}
              </span>
            </div>
            <p className="text-lg">{getRecommendationText()}</p>
            <Badge variant="outline" className="flex items-center gap-1 w-fit mx-auto">
              <TrendingUp className="w-3 h-3" />
              {prediction.confidence.toFixed(1)}% Confidence
            </Badge>
          </div>

          {/* Risk Breakdown */}
          <div className="space-y-4">
            <h3 className="flex items-center gap-2">
              <Satellite className="w-4 h-4" />
              NASA Earth Observation Analysis
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(prediction.riskScores).map(([key, value]) => (
                <div key={key} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="capitalize text-sm">{key.replace('-', ' ')}</span>
                    <span className="text-sm font-medium">{value.toFixed(0)}%</span>
                  </div>
                  <Progress value={value} className="h-2" />
                </div>
              ))}
            </div>
          </div>

          {/* Satellite Data */}
          <div className="bg-muted/50 rounded-lg p-4 space-y-3">
            <h4>Real-time Satellite Measurements</h4>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
              <div>
                <div className="text-muted-foreground">Precipitation</div>
                <div className="font-medium">{prediction.satelliteData.precipitationEstimate.toFixed(1)} mm/hr</div>
              </div>
              <div>
                <div className="text-muted-foreground">Cloud Cover</div>
                <div className="font-medium">{prediction.satelliteData.cloudCover.toFixed(0)}%</div>
              </div>
              <div>
                <div className="text-muted-foreground">Humidity</div>
                <div className="font-medium">{prediction.satelliteData.humidity.toFixed(0)}%</div>
              </div>
              <div>
                <div className="text-muted-foreground">Temperature</div>
                <div className="font-medium">{prediction.satelliteData.temperature.toFixed(1)}°C</div>
              </div>
              <div>
                <div className="text-muted-foreground">Wind Speed</div>
                <div className="font-medium">{prediction.satelliteData.windSpeed.toFixed(1)} km/h</div>
              </div>
              <div>
                <div className="text-muted-foreground">Pressure</div>
                <div className="font-medium">{prediction.satelliteData.pressure.toFixed(0)} hPa</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Visual Weather Map */}
      <Card>
        <CardHeader>
          <CardTitle>Satellite Weather Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative rounded-lg overflow-hidden bg-muted">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1660839178653-7f9d01642105?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYXRlbGxpdGUlMjB3ZWF0aGVyJTIwcmFkYXIlMjBzdG9ybSUyMGNsb3Vkc3xlbnwxfHx8fDE3NTk2ODI1NDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Satellite weather data visualization"
              className="w-full h-64 object-cover"
            />
            <div className="absolute top-4 left-4 bg-black/70 text-white px-3 py-1 rounded text-sm">
              Live NASA Satellite Data
            </div>
            <div className="absolute bottom-4 right-4 bg-white/90 px-3 py-1 rounded text-sm">
              {queryData.location}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}