import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { MapPin, Calendar, Clock, Search } from 'lucide-react';

interface WeatherQueryProps {
  onQuery: (data: {
    location: string;
    date: string;
    time: string;
    eventType: string;
    riskType: string;
  }) => void;
}

export function WeatherQuery({ onQuery }: WeatherQueryProps) {
  const [location, setLocation] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [eventType, setEventType] = useState('');
  const [riskType, setRiskType] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (location && date && time && eventType && riskType) {
      onQuery({ location, date, time, eventType, riskType });
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="w-5 h-5" />
          Plan Your Perfect Event
        </CardTitle>
        <p className="text-muted-foreground">
          Get AI-powered weather predictions using NASA Earth observation data
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="location" className="flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Location
            </Label>
            <Input
              id="location"
              placeholder="Enter city, landmark, or coordinates"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date" className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Date
              </Label>
              <Input
                id="date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="time" className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Time
              </Label>
              <Input
                id="time"
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Event Type</Label>
            <Select value={eventType} onValueChange={setEventType} required>
              <SelectTrigger>
                <SelectValue placeholder="Select your event type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="outdoor-wedding">Outdoor Wedding</SelectItem>
                <SelectItem value="hiking">Hiking/Trail Walking</SelectItem>
                <SelectItem value="fishing">Fishing</SelectItem>
                <SelectItem value="camping">Camping</SelectItem>
                <SelectItem value="sports">Sports Event</SelectItem>
                <SelectItem value="festival">Festival/Concert</SelectItem>
                <SelectItem value="picnic">Picnic/BBQ</SelectItem>
                <SelectItem value="photography">Photography Session</SelectItem>
                <SelectItem value="other">Other Outdoor Activity</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Primary Weather Concern</Label>
            <Select value={riskType} onValueChange={setRiskType} required>
              <SelectTrigger>
                <SelectValue placeholder="What weather condition worries you most?" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="very-wet">Very Wet (Rain/Precipitation)</SelectItem>
                <SelectItem value="very-hot">Very Hot (High Temperature)</SelectItem>
                <SelectItem value="very-cold">Very Cold (Low Temperature)</SelectItem>
                <SelectItem value="very-windy">Very Windy (High Wind Speed)</SelectItem>
                <SelectItem value="very-uncomfortable">Very Uncomfortable (Humidity/Heat Index)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button type="submit" className="w-full">
            Analyze Weather Risk
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}