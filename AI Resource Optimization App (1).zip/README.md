
  # AI Resource Optimization App

  This is a code bundle for AI Resource Optimization App. The original project is available at https://www.figma.com/design/m1t6j8JrMfgIqiGfWXF9hv/AI-Resource-Optimization-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  